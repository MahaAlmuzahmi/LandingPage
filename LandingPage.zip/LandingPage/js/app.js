/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

// Global Variables
// get all section elements
const sections = document.querySelectorAll('section');
const navbar__list = document.getElementById("navbar__list");
// get all navigation links
const navLinks = document.querySelectorAll('.menu__link');
// to hide/show the fixed navbar on scroll
let preScrollPos = window.pageYOffset;


// built navigation dynamically as an unordered list.
document.addEventListener("DOMContentLoaded", function() {
 sections.forEach((section) => {
     const listItem = document.createElement("li");
     const aLink = document.createElement("a");
     aLink.textContent = section.getAttribute("data-nav");
     aLink.href = `#${section.id}`;
     aLink.classList='.menu__link';
     

     aLink.addEventListener('click', (event) => {
        event.preventDefault();
        scrollToSection(section.id);

        // Remove the 'active' class from all links
        navbar__list.querySelectorAll('a').forEach((link) => link.classList.remove('active'));

        // Add the 'active' class to the clicked link
        aLink.classList.add('active');
    });
    listItem.appendChild(aLink);
     navbar__list.appendChild(listItem);
 });

// this function to check if an element is in the viewport
function isInViewport(e) {
    const rect = e.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }
  
  // Add scroll event listener to the window
  window.addEventListener('scroll', handleScroll);

  // this function to smoothly scroll to a section
    function scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        window.scrollTo({
            top: section.offsetTop - 50,
            behavior: 'smooth'
        });
    }
});


// This code for hide fixed navigation bar while not scrolling

// on window scroll
window.addEventListener('scroll', () => {
    let curntSection = '';

    sections.forEach((section) => {
        const section_Top = section.offsetTop - 150;
        const section_Bottom = section_Top + section.clientHeight;

        if (window.scrollY >= section_Top && window.scrollY < section_Bottom) {
            curntSection = section.id;
        }
    });
    // remove the 'active' class from all links
    navLinks.forEach((link) => link.classList.remove('active'));
    // add the 'active' class to the current section
    const activeLink = document.querySelector(`.menu__link[href="#${curntSection}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    //this code for add class to active state on the navigation items when a section is in the viewport
    // first create loop for each section
    sections.forEach( section => {
      // then get px distance from top
      const topDistance = section.getBoundingClientRect().top;
      // if the distance to the top is between 0-100px add the 'active' class
      if (topDistance > 0 && topDistance < 100) {
        section.classList.add('your-active-class');
      // remove the class
      } else {
        section.classList.remove('your-active-class');
      }
    });
  });


// get the scroll to Top button
let scrolltoTopbtn = document.getElementById("scrolltoTopbtn");

// When the user scrolls down 30px from the top of the document will show the button top
window.onscroll = function() {scrolltotopFunction()};

function scrolltotopFunction() {
 if (document.body.scrollTop > 30 || document.documentElement.scrollTop > 30) {
   scrolltoTopbtn.style.display = "block";
 } else {
   scrolltoTopbtn.style.display = "none";
 }
}

// When clicks on the button it will scroll to the top of the document
function scrollToTop() {
 document.body.scrollTop = 0;
 document.documentElement.scrollTop = 0;
}

// to make sections collapsible
var collapsible = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < collapsible.length; i++) {
 collapsible[i].addEventListener("click", function() {
   this.classList.toggle("active");
   var content = this.nextElementSibling;
   if (content.style.display === "block") {
     content.style.display = "none";
   } else {
     content.style.display = "block";
   }
 });
}



