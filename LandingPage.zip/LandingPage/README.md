# Landing Page Project

## Table of Contents

* [Overview](#overview)
* [Features](#features)
* [Preview](#preview)

## Overview

Welcome to the Landing Page Project! This project aims to create an engaging landing page for [Middle East]. The landing page serves as the first point of contact for visitors, providing essential information Middle East.

## Features

  - Usable across modern desktop, tablet, and phone browsers.
  - Responsive
  - Easy Customization, Simple structure and well-commented code according to your specific needs.
  
## Preview
##### Build the navigation menu dynamic
![alt text](./screenshoot/navg.png)
##### Remove and add the 'active' class to the clicked link
![alt text](./screenshoot/active.png)
##### Function to smoothly scroll to a section
![alt text](./screenshoot/smooth.png)
##### link app.js into index.html
![alt text](./screenshoot/p3link.png)
##### .getBoundingClientRect() function to active state on navigation items when a section is in the viewport
![alt text](./screenshoot/p4.png)
##### Hide fixed navigation bar while not scrolling
![alt text](./screenshoot/p5.png)
##### Add a scroll to the top button 
![alt text](./screenshoot/p6.png)
##### Make sections collapsible
![alt text](./screenshoot/p7.png)
